#include "inventario.h"
#include "producto.h"
#include "tienda.h"
#include "carrito.h"

int main(){
    Tienda tiendaEliAbi = Tienda();
    tiendaEliAbi.mostrar_opciones();
}